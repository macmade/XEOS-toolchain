NMake Makefiles JOM
-------------------

Generates JOM makefiles.
