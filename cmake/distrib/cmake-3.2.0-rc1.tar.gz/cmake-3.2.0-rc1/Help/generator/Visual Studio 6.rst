Visual Studio 6
---------------

Generates Visual Studio 6 project files.
